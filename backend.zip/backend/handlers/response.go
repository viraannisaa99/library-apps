package handlers

import "github.com/gin-gonic/gin"

func respondSuccess(c *gin.Context, status int, data any) {
	c.JSON(status, gin.H{"data": data, "messsage": "success"})
}

func respondError(c *gin.Context, status int, message string) {
	c.JSON(status, gin.H{"error": message})
}
