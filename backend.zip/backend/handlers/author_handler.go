package handlers

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/vira/go-crud/entities"
	"github.com/vira/go-crud/services"
)

type AuthorHandler struct {
	service *services.AuthorService
}

func NewAuthorHandler(service *services.AuthorService) *AuthorHandler {
	return &AuthorHandler{service}
}

// GET /authors
func (h *AuthorHandler) GetAll(c *gin.Context) {
	authors, err := h.service.GetAll()
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondSuccess(c, http.StatusOK, authors)
}

// GET /authors/:id
func (h *AuthorHandler) GetByID(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		respondError(c, http.StatusBadRequest, "invalid id")
		return
	}

	author, err := h.service.GetByID(id)
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, services.ErrAuthorNotFound) {
			status = http.StatusNotFound
		}
		respondError(c, status, err.Error())
		return
	}
	respondSuccess(c, http.StatusOK, author)
}

// POST /authors
func (h *AuthorHandler) Create(c *gin.Context) {
	var req entities.CreateAuthorRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}

	author, err := h.service.Create(req)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondSuccess(c, http.StatusCreated, author)
}

// PUT /authors/:id
func (h *AuthorHandler) Update(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		respondError(c, http.StatusBadRequest, "invalid id")
		return
	}

	var req entities.UpdateAuthorRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}

	author, err := h.service.Update(id, req)
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, services.ErrAuthorNotFound) {
			status = http.StatusNotFound
		}
		respondError(c, status, err.Error())
		return
	}
	respondSuccess(c, http.StatusOK, author)
}

// DELETE /authors/:id
func (h *AuthorHandler) Delete(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		respondError(c, http.StatusBadRequest, "invalid id")
		return
	}

	if err := h.service.Delete(id); err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, services.ErrAuthorNotFound) {
			status = http.StatusNotFound
		}
		respondError(c, status, err.Error())
		return
	}
	respondSuccess(c, http.StatusOK, "author deleted")
}
